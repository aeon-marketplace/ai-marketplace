# ÆON AI Playground — Free-tier model tester

## Run on Windows
1. Extract the ZIP completely. Open the **inner** `AEON-VSCode-Model-Test-Playground` folder in VS Code (the folder containing `package.json`).
2. Open Terminal → New Terminal. If PowerShell blocks `npm.ps1`, use `npm.cmd` instead:

```powershell
npm.cmd install
npm.cmd run check
npm.cmd start
```

3. Open http://localhost:3000

Requires Node.js 20+. API keys are kept only in backend process memory and clear when the server restarts. Do not expose this prototype publicly.

## Model access and limitations (free-only mode)
- **Groq text-to-text:** lists GPT OSS 20B, GPT OSS 120B and Qwen 3.8 27B when supported. Groq's published Free Plan table currently lists up to 30 requests/min, 1,000 requests/day, 8,000 tokens/min and 200,000 tokens/day for these model IDs; actual account limits can differ. The catalog intersects these IDs with the models returned by your Groq API key when possible.
- **OpenAI:** no OpenAI model is included in the free-only catalog. OpenAI API usage is billed separately from ChatGPT Free; the app blocks OpenAI inference to avoid accidental charges. A promotional credit balance is account-specific and cannot be safely verified by this local app.
- **Hugging Face text-to-text:** only lists routes discovered through the live Hub PublicAI filter (a route described by Hugging Face as free at time of writing) or routes explicitly marked free/zero-priced by the authenticated router. A route may still be unavailable or rate-limited.
- **Google Gemini:** includes free-tier candidates; Google AI Studio quotas depend on model and account. If an ID is not supported by your account, refresh/choose a different listed model.
- **OpenRouter:** fetches the live catalog and includes only models with `:free` IDs or zero input/output token pricing, plus `openrouter/free`.
- **Cohere:** the provider remains available in the UI, but no model is listed or runnable in free-only mode unless a free route is explicitly added to the catalog in a future update.
- **Text-to-image:** Hugging Face image generation uses a separate limited-credit route. It is not guaranteed free indefinitely; check the free credit balance and avoid using it if your account requires payment. The text model free-only gate does not convert image endpoints into free routes.
- The backend blocks custom model IDs that are not in the free-only text catalog. No paid fallback is used.

## If a model fails
1. Use **Models → Refresh catalog**.
2. Save the provider API key first, then refresh so supported model IDs can be checked.
3. For Groq, check the official Limits page if you hit HTTP 429; wait for the relevant reset window.
4. For Hugging Face, choose a model marked free and check current provider route/credit status.
5. OpenAI inference is intentionally blocked in free-only mode; a ChatGPT subscription does not include API usage.

## Official sources
- Gemini model IDs: https://ai.google.dev/gemini-api/docs/models
- Gemini pricing/free tier: https://ai.google.dev/gemini-api/docs/pricing
- OpenRouter free models: https://openrouter.ai/collections/free-models/
- OpenRouter image API/model availability: https://openrouter.ai/docs/api/api-reference/images/list-image-models
- Groq supported models: https://console.groq.com/docs/models
- Groq rate limits: https://console.groq.com/docs/rate-limits
- OpenAI API billing separate from ChatGPT: https://help.openai.com/en/articles/9039756-managing-billing-for-chatgpt-and-the-api-platform
- Hugging Face Inference Providers and free credits: https://huggingface.co/docs/hub/models-inference
- Cohere docs: https://docs.cohere.com
