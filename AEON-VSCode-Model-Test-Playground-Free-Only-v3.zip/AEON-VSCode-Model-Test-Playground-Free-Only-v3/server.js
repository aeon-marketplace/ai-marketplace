import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const keys = new Map(); // session-only process memory
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(root, "public")));

const providers = [
  { id: "gemini", name: "Google Gemini", envName: "GEMINI_API_KEY", docs: "https://ai.google.dev/gemini-api/docs" },
  { id: "groq", name: "Groq", envName: "GROQ_API_KEY", docs: "https://console.groq.com/docs" },
  { id: "openrouter", name: "OpenRouter", envName: "OPENROUTER_API_KEY", docs: "https://openrouter.ai/models" },
  { id: "openai", name: "OpenAI", envName: "OPENAI_API_KEY", docs: "https://platform.openai.com/docs" },
  { id: "huggingface", name: "Hugging Face Inference", envName: "HF_TOKEN", docs: "https://huggingface.co/docs/inference-providers" },
  { id: "cohere", name: "Cohere", envName: "COHERE_API_KEY", docs: "https://docs.cohere.com" }
];

// Free-only text models. Groq entries are taken from its documented Free Plan limits;
// OpenAI is intentionally excluded because API models are metered/billed and ChatGPT Free
// does not include API usage. Live catalogs below add only routes explicitly marked free.
const groqFreeSpecs = [
  { provider: "groq", name: "GPT OSS 20B (Groq Free Plan)", id: "openai/gpt-oss-20b", task: "Text-to-text", access: "Groq Free Plan limits listed: 30 requests/min, 1,000 requests/day, 8,000 tokens/min, 200,000 tokens/day (account/model limits may vary).", note: "Free-plan candidate from Groq's published rate-limit table; requires a Groq API key and current model access." },
  { provider: "groq", name: "GPT OSS 120B (Groq Free Plan)", id: "openai/gpt-oss-120b", task: "Text-to-text", access: "Groq Free Plan limits listed: 30 requests/min, 1,000 requests/day, 8,000 tokens/min, 200,000 tokens/day (account/model limits may vary).", note: "Free-plan candidate from Groq's published rate-limit table; requires a Groq API key and current model access." },
  { provider: "groq", name: "Qwen 3.8 27B (Groq Free Plan)", id: "qwen/qwen3.8-27b", task: "Text-to-text", access: "Groq Free Plan limits listed: 30 requests/min, 1,000 requests/day, 8,000 tokens/min, 200,000 tokens/day (account/model limits may vary).", note: "Free-plan candidate from Groq's published rate-limit table; requires a Groq API key and current model access." }
];
const baseModels = [
  { provider: "gemini", name: "Gemini 3.5 Flash-Lite", id: "gemini-3.5-flash-lite", task: "Text-to-text + vision input", access: "Google AI Studio free-tier quota applies; limits vary by model and region.", note: "Use only if this exact ID appears in your Google AI Studio model list; availability can vary by account." },
  { provider: "gemini", name: "Gemini 3.5 Flash", id: "gemini-3.5-flash", task: "Text-to-text + vision input", access: "Google AI Studio free-tier quota applies; limits vary by model and region.", note: "Use only if this exact ID appears in your Google AI Studio model list; availability can vary by account." },
  { provider: "gemini", name: "Gemini 3.1 Flash-Lite", id: "gemini-3.1-flash-lite", task: "Text-to-text + vision input", access: "Google AI Studio free-tier quota applies; limits vary by model and region.", note: "Use only if this exact ID appears in your Google AI Studio model list; availability can vary by account." },
  { provider: "openrouter", name: "OpenRouter Free Auto Router", id: "openrouter/free", task: "Text-to-text", access: "Free-only router; eligible models, capacity and rate limits can change.", note: "Routes to an eligible free model; no paid route is requested by this model ID." },
  ...groqFreeSpecs
];
const liveFreeIds = { openrouter: new Set(["openrouter/free"]), huggingface: new Set(), groq: new Set(groqFreeSpecs.map(m => m.id)) };
const imageModels = [
  { provider: "huggingface", name: "Stable Diffusion XL (HF Inference candidate)", id: "stabilityai/stable-diffusion-xl-base-1.0", task: "Text-to-image", access: "Limited HF monthly credits; availability varies", note: "Uses Hugging Face Inference; the account/model must have a compatible inference provider." },
  { provider: "huggingface", name: "FLUX.1 Schnell (HF Inference candidate)", id: "black-forest-labs/FLUX.1-schnell", task: "Text-to-image", access: "Limited HF monthly credits; availability varies", note: "Some models may be gated or unavailable through serverless inference." }
];

app.get("/api/health", (_q, r) => r.json({ ok: true, node: process.version, providersConfigured: keys.size }));
app.get("/api/providers", (_q, r) => r.json(providers.map(p => ({ ...p, connected: keys.has(p.id), keySource: keys.has(p.id) ? "Session memory" : "Not connected" }))));
app.put("/api/keys/:id", (q, r) => {
  const p = providers.find(x => x.id === q.params.id);
  if (!p) return r.status(404).json({ error: "Unknown provider." });
  const key = String(q.body?.key || "").trim();
  if (!key) return r.status(400).json({ error: "Enter an API key first." });
  keys.set(p.id, key);
  r.json({ ok: true, message: `${p.name} key stored in server memory until restart.` });
});
app.delete("/api/keys/:id", (q, r) => {
  if (!providers.some(p => p.id === q.params.id)) return r.status(404).json({ error: "Unknown provider." });
  keys.delete(q.params.id);
  r.json({ ok: true, message: "Key removed from server memory." });
});

async function fetchOpenRouterFreeModels() {
  try {
    const response = await fetch("https://openrouter.ai/api/v1/models", { signal: AbortSignal.timeout(10000) });
    if (!response.ok) return [];
    const data = await response.json();
    const found = (data.data || []).filter(m => {
      const p = m.pricing || {};
      const outputs = m.architecture?.output_modalities || [];
      return !outputs.includes("image") && (String(m.id || "").endsWith(":free") || (Number(p.prompt) === 0 && Number(p.completion) === 0));
    }).map(m => ({ provider: "openrouter", name: `${m.name || m.id} (free route)`, id: m.id, task: "Text-to-text", access: "OpenRouter catalog reports zero token pricing / free route; limits and capacity apply.", note: "Discovered from OpenRouter's live model catalog. Free route availability can change." }));
    liveFreeIds.openrouter = new Set(["openrouter/free", ...found.map(m => m.id)]);
    return found;
  } catch { return []; }
}
async function fetchGroqFreeModels(token) {
  if (!token) return groqFreeSpecs;
  try {
    const response = await fetch("https://api.groq.com/openai/v1/models", { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(10000) });
    if (!response.ok) return groqFreeSpecs;
    const data = await response.json();
    const supported = new Set((data.data || []).map(m => m.id));
    return groqFreeSpecs.filter(m => supported.has(m.id));
  } catch { return groqFreeSpecs; }
}
async function fetchHuggingFaceFreeModels(token) {
  if (!token) { liveFreeIds.huggingface = new Set(); return []; }
  const out = [];
  // PublicAI is documented by Hugging Face as a free inference utility at the time of writing.
  // Only list model IDs returned by the live Hub filter for that provider.
  try {
    const response = await fetch("https://huggingface.co/api/models?pipeline_tag=text-generation&inference_provider=publicai&sort=downloads&direction=-1&limit=100", { signal: AbortSignal.timeout(12000) });
    if (response.ok) {
      const data = await response.json();
      for (const m of (Array.isArray(data) ? data : [])) {
        if (!m.id) continue;
        out.push({ provider: "huggingface", name: `${m.id} — PublicAI (free route)`, id: `${m.id}:publicai`, task: "Text-to-text", access: "PublicAI route listed as free by Hugging Face; availability/capacity can change. Hugging Face free users also receive limited monthly inference credits (currently $0.10, subject to change) for eligible routes.", note: "Discovered from the live Hugging Face Hub filter for PublicAI. Requires your HF token." });
      }
    }
  } catch {}
  // Also accept other routes only if the authenticated router explicitly marks them free/zero-priced.
  try {
    const response = await fetch("https://router.huggingface.co/v1/models", { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(12000) });
    if (response.ok) {
      const data = await response.json();
      for (const m of (data.data || [])) {
        if (!(m.architecture?.output_modalities || ["text"]).includes("text")) continue;
        for (const provider of (m.providers || [])) {
          const pricing = provider.pricing || {};
          const zeroPrice = Number(pricing.input) === 0 && Number(pricing.output) === 0;
          if (provider.status && provider.status !== "live") continue;
          if (provider.is_free !== true && !zeroPrice) continue;
          const providerId = String(provider.provider || "").trim();
          if (!providerId || !m.id) continue;
          out.push({ provider: "huggingface", name: `${m.id} — ${providerId} (free route)`, id: `${m.id}:${providerId}`, task: "Text-to-text", access: "Hugging Face router explicitly marks this provider route free/zero-priced; quotas apply.", note: `Live catalog route: ${providerId}.` });
        }
      }
    }
  } catch {}
  liveFreeIds.huggingface = new Set(out.map(m => m.id));
  return [...new Map(out.map(m => [m.id, m])).values()];
}
app.get("/api/models", async (q, r) => {
  const [liveFree, hfFree, groqFree] = await Promise.all([
    fetchOpenRouterFreeModels(),
    fetchHuggingFaceFreeModels(keys.get("huggingface")),
    fetchGroqFreeModels(keys.get("groq"))
  ]);
  liveFreeIds.groq = new Set(groqFree.map(m => m.id));
  const all = [...baseModels.filter(m => m.provider !== "groq"), ...groqFree, ...liveFree, ...hfFree];
  const unique = [...new Map(all.map(m => [`${m.provider}:${m.id}`, m])).values()];
  r.json({ models: unique.filter(m => !q.query.provider || q.query.provider === "all" || m.provider === q.query.provider), refreshed: new Date().toISOString(), notice: "Free-only catalog: Groq documented Free Plan candidates, Google free-tier candidates, and live OpenRouter/Hugging Face routes explicitly marked free. OpenAI API models are excluded because API usage is metered; ChatGPT Free does not include API usage." });
});
app.get("/api/image-models", (_q, r) => r.json({ models: imageModels, notice: "No provider guarantees unlimited free image generation. Hugging Face may provide limited monthly credits; generation can fail if the model/provider is unavailable." }));

async function parseResponse(response) {
  const raw = await response.text();
  try { return { data: JSON.parse(raw), raw }; } catch { return { data: { raw: raw.slice(0, 1000) }, raw }; }
}
async function callModel(id, model, message, key, maxTokens = 800) {
  let url, headers = { "Content-Type": "application/json" }, body;
  if (id === "gemini") {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
    headers["x-goog-api-key"] = key;
    body = { contents: [{ role: "user", parts: [{ text: message }] }], generationConfig: { maxOutputTokens: maxTokens, temperature: 0.3 } };
  } else if (["groq", "openrouter", "openai", "huggingface"].includes(id)) {
    url = { groq: "https://api.groq.com/openai/v1/chat/completions", openrouter: "https://openrouter.ai/api/v1/chat/completions", openai: "https://api.openai.com/v1/chat/completions", huggingface: "https://router.huggingface.co/v1/chat/completions" }[id];
    headers.Authorization = `Bearer ${key}`;
    if (id === "openrouter") { headers["HTTP-Referer"] = "http://localhost:3000"; headers["X-Title"] = "AEON Local Model Tester"; }
    body = { model, messages: [{ role: "user", content: message }], max_tokens: maxTokens, temperature: 0.3 };
  } else if (id === "cohere") {
    url = "https://api.cohere.com/v2/chat"; headers.Authorization = `Bearer ${key}`;
    body = { model, messages: [{ role: "user", content: message }], max_tokens: maxTokens, temperature: 0.3 };
  } else throw new Error("Unknown provider.");
  const response = await fetch(url, { method: "POST", headers, body: JSON.stringify(body), signal: AbortSignal.timeout(30000) });
  const { data } = await parseResponse(response);
  if (!response.ok) throw Object.assign(new Error(String(data?.error?.message || data?.message || data?.detail || data?.raw || `HTTP ${response.status}`).slice(0, 900)), { status: response.status });
  const answer = id === "gemini" ? (data?.candidates?.[0]?.content?.parts || []).map(x => x.text || "").join("") : id === "cohere" ? (data?.message?.content || []).map(x => x.text || "").join("") : (data?.choices?.[0]?.message?.content || "");
  if (!answer.trim()) throw new Error("Provider returned no readable text. Check model ID and task compatibility.");
  return { answer, model: data?.model || model, usage: data?.usage || data?.usageMetadata || null };
}
function hint(e, provider, model) {
  const s = String(e.message).toLowerCase();
  if (provider === "gemini" && (model.includes("2.5-flash-lite") || s.includes("no longer available to new users"))) return "This Gemini model is restricted for new users. Select gemini-3.5-flash-lite in the model list and retry.";
  if ((s.includes("401") || s.includes("unauthorized") || s.includes("invalid api key"))) return "Check that the API key is correct and active.";
  if (s.includes("429") || s.includes("quota") || s.includes("billing") || s.includes("rate limit")) return "Quota/rate limit reached. Try another free model or wait for the quota reset.";
  if (provider === "groq" && (s.includes("model") && (s.includes("not found") || s.includes("decommissioned") || s.includes("unsupported")))) return "This Groq model may have been retired or may not be enabled for your account. Refresh the catalog; only current Free Plan candidates are listed.";
  if (provider === "openai") return "OpenAI API usage is billed separately from ChatGPT Free; no OpenAI model is enabled in free-only mode.";
  if (provider === "openrouter" && (s.includes("unavailable for free") || s.includes("no endpoints") || s.includes("no provider"))) return "That model is not currently free/available. Refresh the catalog and select a model marked free, or use openrouter/free.";
  if (provider === "huggingface" && (s.includes("not supported by any provider") || s.includes("no provider") || s.includes("model_not_supported"))) return "This Hugging Face model has no compatible inference provider for your account. Open API Keys, save your Hugging Face token, then refresh the Models catalog and choose a route marked currently free. The selected route includes its provider suffix.";
  if (s.includes("model") && (s.includes("not found") || s.includes("unsupported") || s.includes("does not exist") || s.includes("deprecated"))) return "Model ID may be outdated or unsupported. Refresh the catalog and use an exact current ID.";
  if (s.includes("abort") || s.includes("timeout")) return "Request timed out. Check provider status and retry.";
  return "Check model ID, key permissions, account quota, provider docs and task compatibility.";
}
function safe(e) { let s = String(e.message || "Provider error"); for (const k of keys.values()) if (k) s = s.split(k).join("[REDACTED]"); return s.slice(0, 900); }
async function run(req, res) {
  const id = req.params.id || String(req.body.provider || "");
  if (!providers.some(p => p.id === id)) return res.status(400).json({ error: "Choose a valid provider." });
  const key = keys.get(id); if (!key) return res.status(400).json({ error: `Add a ${providers.find(p => p.id === id).name} API key first.` });
  const model = String(req.body.model || "").trim(), message = String(req.body.message || "").trim();
  if (!model) return res.status(400).json({ error: "Choose a model or enter an exact model ID." });
  if (!message) return res.status(400).json({ error: "Type a message first." });
  if (message.length > 20000) return res.status(400).json({ error: "Message limit is 20,000 characters." });
  // Enforce free-only mode on the server too; a custom ID must not bypass the catalog.
  if (id === "openai") return res.status(403).json({ error: "OpenAI has no generally free API model catalog. API usage is billed separately from ChatGPT Free, so OpenAI inference is disabled in this free-only playground to prevent unexpected charges.", hint: "Use Groq Free Plan, a live OpenRouter free route, or a Hugging Face route marked free. If your OpenAI API account has promotional credits, check its billing page; this app cannot verify that balance safely." });
  const listed = id === "gemini" ? baseModels.some(m => m.provider === id && m.id === model)
    : id === "groq" ? liveFreeIds.groq.has(model)
    : id === "openrouter" ? liveFreeIds.openrouter.has(model)
    : id === "huggingface" ? liveFreeIds.huggingface.has(model)
    : false;
  if (!listed) return res.status(403).json({ error: `Model '${model}' is not in the current free-only catalog for ${id}.`, hint: "Refresh Models and choose an entry explicitly listed as free. Custom model IDs are blocked if they are not verified in the free-only catalog." });
  try {
    const result = await callModel(id, model, message, key, req.path.includes("/test/") ? 40 : 800);
    res.json({ ok: true, provider: providers.find(p => p.id === id).name, ...result, message: "Real inference succeeded. This does not guarantee future use will be free." });
  } catch (e) { res.status(e.status || 502).json({ error: safe(e), hint: hint(e, id, model) }); }
}
app.post("/api/test/:id", async (q, r) => { q.body = { ...(q.body || {}), message: "Reply with exactly: AEON connection test successful" }; await run(q, r); });
app.post("/api/chat", run);

// Hugging Face image generation is a real provider call; response bytes are returned for preview.
app.post("/api/image", async (req, res) => {
  const id = "huggingface", key = keys.get(id);
  if (!key) return res.status(400).json({ error: "Add your Hugging Face token in API Keys first.", hint: "HF Inference may include limited monthly credits; check your current balance." });
  const model = String(req.body?.model || "stabilityai/stable-diffusion-xl-base-1.0").trim();
  const prompt = String(req.body?.prompt || "").trim();
  if (!prompt) return res.status(400).json({ error: "Enter an image prompt first." });
  if (prompt.length > 4000) return res.status(400).json({ error: "Image prompt must be 4,000 characters or fewer." });
  try {
    const url = `https://router.huggingface.co/hf-inference/models/${model.split("/").map(encodeURIComponent).join("/")}`;
    const response = await fetch(url, { method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", Accept: "image/*, application/json" }, body: JSON.stringify({ inputs: prompt, options: { wait_for_model: true } }), signal: AbortSignal.timeout(120000) });
    const contentType = response.headers.get("content-type") || "";
    if (!response.ok || contentType.includes("json") || contentType.includes("text")) {
      const raw = await response.text(); let data; try { data = JSON.parse(raw); } catch { data = { error: raw.slice(0, 900) }; }
      const message = data?.error || data?.message || raw || `HTTP ${response.status}`;
      const lower = String(message).toLowerCase();
      const hint = lower.includes("loading") || lower.includes("estimated_time") ? "Model is loading; retry in 20–60 seconds." : lower.includes("gated") || lower.includes("access") ? "This model may be gated. Accept its license on Hugging Face or choose another model." : lower.includes("credit") || lower.includes("payment") ? "Free credits may be exhausted or this model requires paid inference." : "Check Hugging Face token permissions and whether the model supports serverless image generation.";
      return res.status(response.status || 502).json({ error: String(message).slice(0, 900), hint });
    }
    const bytes = Buffer.from(await response.arrayBuffer());
    if (!bytes.length) return res.status(502).json({ error: "Provider returned an empty image." });
    const mime = contentType.startsWith("image/") ? contentType.split(";")[0] : "image/png";
    res.json({ ok: true, model, mime, image: `data:${mime};base64,${bytes.toString("base64")}`, message: "Image returned by Hugging Face Inference. Check credits and pricing before repeated use." });
  } catch (e) { res.status(502).json({ error: safe(e), hint: "Image inference timed out or the provider is unavailable. Retry or test another supported model." }); }
});
app.listen(PORT, () => console.log(`ÆON AI Playground: http://localhost:${PORT}\nAPI keys remain in process memory and clear on restart.`));
